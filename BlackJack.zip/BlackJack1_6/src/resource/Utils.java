/*
 Group: Edsel Rudy, Giancarlo Soriano, Jasmine Santos, Paprawin Boonyakida
 Professor Elizabeth Miller
 Course: CIT 285-01
 Date: 11/24/16

Description: This class holds the basic utilities for the game such as images and animation

This class provides functions that load images from our resource folders, including the
cards, icons, and screen background (which we can modify later on).


*/

/**
 * The utils class handles the images and display 
 * basic player information (Bet, hand value, and name)for the game.
 * 
 * @author Edsel Rudy, Jasmine Santos, Paprawin Boonyakida, Giancarlo Soriano
 * @version 1.2
 * @since 11/20/16
 */
package resource;

import base.Card;
import base.Hand;
import base.Player;
import java.io.InputStream;
import javafx.animation.Animation;
import javafx.animation.FadeTransition;
import javafx.animation.ScaleTransition;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.util.Duration;


public class Utils {

    //Initialize strings that represent the image folders
    public final String RESOURCES_FOLDER = "/resource/";
    public final String IMAGE_FOLDER = RESOURCES_FOLDER + "images/";
    public final String CARD_FOLDER = "Card/";

    /**
     * getImage browse for the images in the resource/images directory
     * 
     * @param imageName the name of the image to be added
     * @return ImageView holds an image
     */
    
    public Image getImage(String imageName) {
        
        InputStream imageInputStream = Utils.class.getResourceAsStream(IMAGE_FOLDER + imageName);
        return new Image(imageInputStream);
    }

    /**
     * This function calls the getImage to retrieve the image, 
     * put in into an ImageView object, and returns it
     * 
     * @param imageName the name of the image to be added
     * @return ImageView holds an image
     */
    public ImageView getImageView(String imageName) {
        
        return new ImageView(getImage(imageName));
    }

    /**
     * getCardImageView() browse resource/images/Card/ directory for the card images
     * 
     * @param imageName the name of the image to be added
     * @return ImageView holds an image
     */
    public ImageView getCardImageView(String imageName) {
        
        return new ImageView(getImage(CARD_FOLDER + imageName.toLowerCase() + ".png"));
    }

    /**
     * This function returns the image of the back side of the card
     * 
     * 
     * @return ImageView holds an image
     */
    public ImageView getHiddenCardImageView() {
        return new ImageView(getImage(CARD_FOLDER + "Backside.png"));
    }

    /**
     * returns the player type icon, either a human or a robot
     * 
     *
     * @return ImageView holds an image
     */
    public ImageView getIconImageView() {
                return new ImageView(getImage("human.jpg"));
        
    }

    /**
     * adds the card images to the hand of the player and essential player information
     * shown in the top left corner of the screen
     * 
     * @param p the current player
     * @param hand the current player's hand
     * @param activePlayer the current player that is supposed to make a move, used to show blinking animation
     * @param activeHand the current player's hand
     * 
     * @return HBox contains the player's cards, name, hand value, and player icon
     */
    public HBox getHandHBox(Player p, Hand hand, Player activePlayer, Hand activeHand) {
        
        // default config for all players
        final HBox playerBox = new HBox(8);
        
        playerBox.setPadding(new Insets(5, 5, 5, 5));
        
        playerBox.setMaxHeight(110);
        playerBox.setPrefWidth(322);
        
        ImageView icon = getIconImageView();
        icon.setFitHeight(42);
        icon.setPreserveRatio(true);
        
        Label nameLbl = new Label(p.getName());
        
        nameLbl.setAlignment(Pos.CENTER_LEFT);
        nameLbl.setPrefHeight(playerBox.getHeight());
        nameLbl.setStyle("-fx-font-family: \"Comic Sans MS\", cursive, sans-serif;"
                + "-fx-font-size: 11pt;"
                + "-fx-font-weight: bold;\n" 
                + "-fx-text-fill: black;");
        
        Label valueLabel = new Label("Hand: " + String.valueOf(hand.cardsValue()));
        valueLabel.setStyle("-fx-font-family: \"Comic Sans MS\", cursive, sans-serif;"
                + "-fx-font-size: 11pt;"
                + "-fx-font-weight: bold;\n" 
                + "-fx-text-fill: white;");
        
        valueLabel.setAlignment(Pos.CENTER_RIGHT);
        valueLabel.setPrefHeight(playerBox.getHeight());
        playerBox.getChildren().addAll(icon, nameLbl, valueLabel);

        // set color according to hand value
        Color color = Color.RED;
        if (p.getCurrentHand().cardsValue() > 21) {
            color = Color.RED; // Red color for busted hand
        }
        if (p.getCurrentHand().cardsValue() == 21) {
            color = Color.GREEN; // Green for winning hand
        }
        if (p.getCurrentHand().cardsValue() < 21) {
            color = Color.YELLOW; // Yellow for regular (non busted) hand
        }
        valueLabel.setTextFill(color); // Set the color

        // add cards images
        for (Card card : hand.getCards()) {
            final ImageView smallCard;
            smallCard = getCardImageView(card.toString().toLowerCase());
            smallCard.setFitHeight(42);
            smallCard.setPreserveRatio(true);

            
            playerBox.getChildren().add(smallCard);
        }

        // install tooltips to display tips
        Tooltip tt = new Tooltip("Money: " + p.getFunds() + "$" + "\nBet: " + hand.getBetAmount() + "$");
        Tooltip.install(playerBox, tt);
        
        // add blinking if this is the active hand in the main view
        if (activePlayer.getName().equals(p.getName()) && hand == activeHand) {
            nameLbl.setStyle("-fx-font-family: \"Comic Sans MS\", cursive, sans-serif;"
                + "-fx-font-size: 11pt;"
                + "-fx-font-weight: bold;\n" 
                + "-fx-text-fill: black;");
            
            
            final FadeTransition animation = new FadeTransition(Duration.millis(1400));
            animation.setNode(playerBox);
            animation.setFromValue(0.0);
            animation.setToValue(1.0);
            animation.setCycleCount(Animation.INDEFINITE);
            animation.setAutoReverse(true);
            animation.setToValue(1.0);
            animation.play();
        }

        return playerBox;
    }

}
