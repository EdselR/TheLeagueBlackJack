/*
 Group: Edsel Rudy, Giancarlo Soriano, Jasmine Santos, Paprawin Boonyakida
 Professor Elizabeth Miller
 Course: CIT 285-01
 Date: 11/24/16

Description: This class updates and initializes the database

//change to client
*/
package resource;

import base.Player;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.List;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class gameClient{

    final int PORT = 8000;
    
    List<Player> highScorePlayers = null;
    
    String ipAddress = "";
    
    private boolean hasConnection = false;
    
    public List<Player> getHighScore(){
        
        return highScorePlayers;
    }
    
    // Checks if the ipAddress is valid
    public boolean makeInitialConnection(String ipAddress){
        
            try{
            
                Socket socket = new Socket(ipAddress, PORT); 
            
                System.out.println("Connected");
            
                Alert connectionMade = new Alert(AlertType.INFORMATION);
                connectionMade.setTitle("Information Dialog");
                connectionMade.setHeaderText("Succesfully connected to the server!");
                connectionMade.setContentText("Please continue with the game");
                
                connectionMade.showAndWait();
                hasConnection = true;
                this.ipAddress = ipAddress; // Save the valid ipAddress to a variable
                ObjectInputStream fromServer = new ObjectInputStream(socket.getInputStream());
                
                highScorePlayers = (List<Player>)fromServer.readObject();
                return true;
                
            }
            //when the server socket is not found, inform the user
            catch(Exception e){
                
                e.printStackTrace();
                return false;

            }
        
    }
    
    public boolean isConnected(){
        return this.hasConnection;
    }
    
    public String getIpAddress(){
        return this.ipAddress;
    }
    
    
    // THE FUNCTION BELOW IS STILL IN PROGRESS. IT WILL DETERMINE IF THE PLAYER EXISTS IN THE DATABASE - Paprawin
    /*
    public Player getExistingPlayer(String playerName){
        
        List<Player> playerList = null;
        try{
            Socket socket = new Socket(ipAddress, PORT);
            System.out.println("Inside send player info");
            
            //create a new object output stream to the socket
                ObjectOutputStream toServer = new ObjectOutputStream(socket.getOutputStream());
                
                System.out.println("Socket connected");
                
                // Send a null object. We programmed the server to not update the database if it receives a null object
                // The reason is because we want the client to just receive the data without updating anything
                toServer.writeObject(null); 
                
                //create a new input stream from the server socket
                ObjectInputStream fromServer = new ObjectInputStream(socket.getInputStream());
                
                playerList = (List<Player>)fromServer.readObject();
          
        }
        //catch a class not found exception if thrown
            catch(ClassNotFoundException x){
                System.out.println("Class Not Found Exception");
            }

        //when the server socket is not found, inform the user
            catch(IOException ex){
                
                Alert connectionFail = new Alert(AlertType.ERROR);
                connectionFail.setTitle("Warning");
                connectionFail.setHeaderText("Failed to connect to the server");
                connectionFail.setContentText("Please enter a valid IP address");
                
                connectionFail.showAndWait();
                 
            }
        
    }
    */
    
    public void sendPlayerInfo(List<Player> currentPlayers, String ipAddress){
        
        try{
            Socket socket = new Socket(ipAddress, PORT);
            System.out.println("Inside send player info");
            
            //create a new object output stream to the socket
                ObjectOutputStream toServer = new ObjectOutputStream(socket.getOutputStream());
                
                System.out.println("Socket connected");
                System.out.println("Attempting to send " + currentPlayers.get(0).getName());
                toServer.writeObject(currentPlayers);
                System.out.println("Client sent player " + currentPlayers.get(0).getName());
                //create a new input stream from the server socket
                ObjectInputStream fromServer = new ObjectInputStream(socket.getInputStream());
                
                highScorePlayers = (List<Player>)fromServer.readObject();
          
        }
        //catch a class not found exception if thrown
            catch(ClassNotFoundException x){
                System.out.println("Class Not Found Exception");
            }

        //when the server socket is not found, inform the user
            catch(IOException ex){
                
                Alert connectionFail = new Alert(AlertType.ERROR);
                connectionFail.setTitle("Warning");
                connectionFail.setHeaderText("Failed to connect to the server");
                connectionFail.setContentText("Please enter a valid IP address");
                
                connectionFail.showAndWait();
                 
            }
        
    }
}

