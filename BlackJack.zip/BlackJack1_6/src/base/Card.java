package base;

import java.io.Serializable;

/*
 Group: Edsel Rudy, Giancarlo Soriano, Jasmine Santos, Paprawin Boonyakida
 Professor Elizabeth Miller
 Course: CIT 285-01
 Date: 11/24/16

Description: This is the card class for the game
 */

// Card Class contain two attributes suit and rank 
abstract public class Card  implements Comparable<Card>, Serializable {
    public Suit suit; // Contain suit of the card
    public Rank rank; // contain card rank 

// Class constructor 
    public Card(Suit suit, Rank rank) {
        this.suit = suit;
        this.rank = rank;
    }
    
// Copy Constructor 
    public Card(Card obj) {
        this.suit = obj.suit;
        this.rank = obj.rank;
    }

// Getters 
    public Suit getSuit() {
        return suit;
    }
    
    public Rank getRank() {
        return rank;
    }  

  // Return the class rank and suit
    @Override
    public String toString() {
        return this.rank.toString() + this.suit.toString();
    }

    // Compares each card by its rank
    @Override
    public int compareTo(Card obj) {
       if (obj == null) {
            return -1;
        }
        if (getClass() != obj.getClass()) {
            return -1;
        }
        final Card other = (Card) obj;
        
        if (this.rank.cardWorth() == other.rank.cardWorth())
            return 1;
        
        else
            return -1;
           
    }

   
}
