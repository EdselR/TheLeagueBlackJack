/*
 Group: Edsel Rudy, Giancarlo Soriano, Jasmine Santos, Paprawin Boonyakida
 Professor Elizabeth Miller
 Course: CIT 285-01
 Date: 11/24/16

Description: This is the suit enum for the game

*/
package base;

// Enums used for the suits of the card

import java.io.Serializable;

  public enum Suit implements Serializable{
                    // Numeric Value
        DIAMONDS,   //    0
        SPADES,     //    1
        CLUBS,      //    2
        HEARTS      //    3
    }
