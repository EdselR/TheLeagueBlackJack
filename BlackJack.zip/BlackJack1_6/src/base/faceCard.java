/*
 Group: Edsel Rudy, Giancarlo Soriano, Jasmine Santos, Paprawin Boonyakida
 Professor Elizabeth Miller
 Course: CIT 285-01
 Date: 11/24/16

Description: This class inherits from the card class.

*/
package base;

import java.io.Serializable;

/**
 *
 * @author EdselR
 */
public class faceCard extends Card implements Serializable{

    Rank aceRank;
    
    public faceCard(Suit suit, Rank rank) {
        super(suit, rank);
    }
    
    public faceCard(Card object){
        super(object);
    }
    
    public boolean isAce(){
        
        if(super.getRank() == aceRank.ACE)
            return true;
        
        else
            return false;
    }
}
