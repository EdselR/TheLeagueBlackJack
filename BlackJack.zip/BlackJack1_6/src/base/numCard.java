/*
 Group: Edsel Rudy, Giancarlo Soriano, Jasmine Santos, Paprawin Boonyakida
 Professor Elizabeth Miller
 Course: CIT 285-01
 Date: 11/24/16

Description: This is the numCard class for the game, creates a regular numcard.

 */
package base;

import java.io.Serializable;

/**
 *
 * @author EdselR
 */
public class numCard extends Card implements Serializable{
    
     public numCard(Suit suit, Rank rank) {
        super(suit, rank);
    }
    
    public numCard(Card object){
        super(object);
    }
    
}
