package base;

import java.io.Serializable;

/*
 Group: Edsel Rudy, Giancarlo Soriano, Jasmine Santos, Paprawin Boonyakida
 Professor Elizabeth Miller
 Course: CIT 285-01
 Date: 11/24/16

Description: This is the handaction class for the game

*/

// Enums used for the HandAction
public enum HandAction implements Serializable{
                   //  Numeric Value
    HIT,           //       0
    SPLIT,         //       1
    DOUBLE,        //       2
    STAND;         //       3
}
