/*
 Group: Edsel Rudy, Giancarlo Soriano, Jasmine Santos, Paprawin Boonyakida
 Professor Elizabeth Miller
 Course: CIT 285-01
 Date: 11/24/16

Description: 
        This is the main class for the Black Jack card game
    Currently, the game can be played as a human and a computer.
    The Player type "computer" is for our quick debugging purpose only.
    We will remove the "computer" player once the game is finalized.
    In this version, the Dealer who deals the card is an AI, meaning
    that the multiplayer interface will only consist of players that 
    will communicate with the server that acts as a card dealer(a computer).
    
            
Last modified: 

24/11/16. Fixed one part of the database error

TODO list: 

1.Indicator showing who've won (FIXED)
2.Help and exit menu toolbar
3.Fix the database function (Player info were saved as duplicates)
4.Implement a high score board
5.Bug where if the player reaches 21 the round still continues
6.Multiplayer implementation
7.Might discuss on whether the "skip round" function is useful
8.Streamline the UI
*/

/**
 * The main app class creates a new table and send it to the game controller 
 * class where the fx is held, the game is then run.
 * 
 * @author Edsel Rudy, Jasmine Santos, Paprawin Boonyakida, Giancarlo Soriano
 * @version 1.2
 * @since 10/07/16
 */
package theleagueblackjack;

import base.Player;
import base.Table;
import java.util.List;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;


public class MainApp extends Application {

    //create a table
    private Table table;

    private Button connect = new Button("Connect");
    
    /**
     * This method overrides the start from application, used in java fx.
     * Uses table and game controller class
     * 
     * @param stage
     * @throws Exception 
     */
    
    @Override
    public void start(Stage stage) throws Exception {

        //set the default table
        table = Table.createDefaultTable();

        //create a new game controller class
        GameController gameController = new GameController();
       
        //set the table and stage
        gameController.setTable(table);
        
        List<Player> currPlayers = table.getPlayers();
        
        for(int i = 0; i < currPlayers.size(); i++){
        
            System.out.println(currPlayers.get(i).getName());
        }
        
        gameController.setStage(stage);
        
        //add the table and css to the scene, adn show the stage
        Scene scene = new Scene(gameController.getMainPain());
        scene.getStylesheets().addAll(this.getClass().getResource("style.css").toExternalForm());
        
        
        stage.setTitle("BlackJack Game");
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();
    }
    /*
    private void connect(List<Player> currentPlayers){

        
            try{
            
                Socket socket = new Socket("172.18.101.135", PORT); 
            
                
                System.out.println("Connected");
            
                DataOutputStream toServerString = new DataOutputStream(socket.getOutputStream());
                
                toServerString.writeUTF("Test");
                
                DataInputStream fromServerString = new DataInputStream(socket.getInputStream());
                
               
                System.out.print(fromServerString.readUTF());
                
            }
            //when the server socket is not found, inform the user
            catch(IOException ex){
                System.out.println("IOException");

            }
    }

    */
    
    /**
     * The is the main method which starts the game
     *
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
