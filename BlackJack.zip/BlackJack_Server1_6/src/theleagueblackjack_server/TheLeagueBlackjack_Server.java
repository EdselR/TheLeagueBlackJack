/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package theleagueblackjack_server;

import base.Player;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.List;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 *
 * @author EdselR
 */
public class TheLeagueBlackjack_Server extends Application {
    
    gameDatabase database = new gameDatabase();
    
    int numClient = 0;
    
    //set the text area to uneditable
        TextArea textArea = new TextArea();
        
    
    @Override
    public void start(Stage primaryStage) {
        VBox main = new VBox(10);

        //set the title's font
        Text title = new Text();
        title.setText("Blackjack Server");
        title.setFont(Font.font("Verdana", 70));
        title.setFill(Color.RED);

        textArea.setEditable(false);

        //add the title and textarea to the client
        main.getChildren().addAll(title, textArea);
        main.setAlignment(Pos.CENTER);

        database.createUser();
        database.createDB();
                
        //set the scene on the stage and show it
        primaryStage.setTitle("Server");
        primaryStage.setScene(new Scene(main,600,400));
        primaryStage.show();

        primaryStage.setResizable(false);

        new Thread(()-> {

            try{
                //create a new server socket
                ServerSocket serverSocket = new ServerSocket(8000);

                //inform he user the server has been created
                Platform.runLater(()-> {

                    textArea.appendText("Server Started at " + new Date() + " \n\n");
                });

                InetAddress servAddress = null;

                //try to get the local host's info
                try{

                    //get the host name and address
                    servAddress = InetAddress.getLocalHost();
                    String servIpAddress = servAddress.getHostAddress();
                    String servHostName = servAddress.getHostName();

                    //inform the user the server's information
                    Platform.runLater(()-> {

                        textArea.appendText(
                                "Host Name: " + servHostName + "\n"
                                        + "Ip Address: " + servIpAddress + "\n\n");
                    });

                }
                //if the host is unknown, inform the user
                catch(UnknownHostException ex){
                    String unknown = "Unknown Host";

                    Platform.runLater(()-> {

                        textArea.appendText(unknown);
                    });
                }


                //keep looking for a socket connection
                while(true){

                    //accept the connection
                    Socket socket = serverSocket.accept();

                    //get the client's info, address and name
                    InetAddress clientAddress = socket.getInetAddress();

                    String clientName = clientAddress.getHostName();
                    String clientIP = clientAddress.getHostAddress();

                    numClient++;
                    //inform the user the client's info
                    Platform.runLater(()-> {

                        textArea.appendText("\nA Client has connected\n"
                                + "Client Name: " + clientName + "\n"
                                + "Client IP: " + clientIP + " \n"
                                + "Sockets used: " + numClient + "\n\n");
                    });
                   ObjectOutputStream outputToClient = new ObjectOutputStream(socket.getOutputStream());
                   // Get a list of players sorted by highscores
                    List<Player> highScoreArray = database.getHighScorePlayers();

                    //Send the updated list back to the client regardless of the received List
                    //When the server receives a null object, the client doesn't want to update the database, but only want to see the list
                    outputToClient.writeObject(highScoreArray);
                    System.out.println("Server sent back list");
                    // This line runs a new thread each time a new client connects to the server
                   new Thread(new HandleIncomingClient(socket)).start();
                }
            }

            //when the server is already running, inform the user
            catch(IOException ex){
                System.out.println("IOException ex");
                ex.printStackTrace();

                Platform.runLater(()-> {

                    textArea.appendText("Server is already running");
                });
            }

        }).start();
    }
    
    class HandleIncomingClient implements Runnable{
        private Socket socket;
        
        public HandleIncomingClient(Socket socket){
            this.socket = socket;
        }
        
        public void run(){
            
            try{
                // Create input and output stream for reading/writing objects 
                ObjectInputStream inputFromClient = new ObjectInputStream(socket.getInputStream());
                ObjectOutputStream outputToClient = new ObjectOutputStream(socket.getOutputStream());

                //Always read each incoming data from a client
                while(true){
                    List<Player> currentPlayers = (List<Player>)inputFromClient.readObject();
                    System.out.println("Server received a list. First person is " + currentPlayers.get(0).getName());

                    //If the list received is not null, save it to the database
                    if(currentPlayers != null){
                        // Save the players' info to the MySQL database
                        database.insertAndUpdatePlayers(currentPlayers);
                    }
                    
                    // Get a list of players sorted by highscores
                    List<Player> highScoreArray = database.getHighScorePlayers();

                    //Send the updated list back to the client regardless of the received List
                    //When the server receives a null object, the client doesn't want to update the database, but only want to see the list
                    outputToClient.writeObject(highScoreArray);
                    System.out.println("Server sent back updated list");

                    //inform the user that the array has been sent
                    Platform.runLater(()-> {

                        textArea.appendText("Wrote to Client\n");
                    });
                }
            }catch(IOException e){
                e.printStackTrace();
            } catch (ClassNotFoundException ex) {
                System.out.println("Class is not found");
            }
        }
}

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        launch(args);
    }
    
}
