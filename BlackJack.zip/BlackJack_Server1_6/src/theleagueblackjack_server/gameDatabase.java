/*
 Group: Edsel Rudy, Giancarlo Soriano, Jasmine Santos, Paprawin Boonyakida
 Professor Elizabeth Miller
 Course: CIT 285-01
 Date: 11/24/16

Description: This class updates and initializes the database

//change to client
*/
package theleagueblackjack_server;

import base.Player;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextInputDialog;

public class gameDatabase{

    static final String DBNAME = "gamedata"; // Database name
    static final String URL = "jdbc:mysql://localhost:3306/";
    static final String USER = "root";
    static final String PASSWORD = "password";
    //static final String PASSWORD = "";
    static final String GAMEUSER = "blackJack";//
    static final String GAMEPASSWORD = "blackjackGame"; //
    static final String TABLENAME = "playerinfo"; // 

    // Important strings to be executed by a Statement
    static String createTable = "CREATE TABLE IF NOT EXISTS " + TABLENAME + "( name VARCHAR(25),r_win INT, r_lose INT, curr_points FLOAT , PRIMARY KEY (name))";
    static String createDatabase = "CREATE DATABASE IF NOT EXISTS " + DBNAME;

    List<Player> highScoreList = new ArrayList<>();
    
    Connection connection = null;

    public void createUser() {
        Connection conn = null;
        Statement stmt = null;

        try {
            //Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Open a connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(URL, USER, PASSWORD);

            System.out.println("Creating user...");
            stmt = conn.createStatement();

            String userCreate = "CREATE USER IF NOT EXISTS '" + GAMEUSER + "'@'%' identified by '" + GAMEPASSWORD + "';";
            stmt.executeUpdate(userCreate);

            String permissions = "grant select, insert, update, delete, create, create view, drop, execute, references on *.* to '" + GAMEUSER
                    + "'@'localhost' identified by '" + GAMEPASSWORD + "';";

            System.out.println(permissions);
            stmt.executeUpdate(permissions);

            permissions = "grant all privileges on *.* to '" + GAMEUSER + "'@'%' identified by '" + GAMEPASSWORD + "';";
            stmt.executeUpdate(permissions);

            System.out.println("user " + GAMEUSER + " created.");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // createDB() creates a database named "gamedata" if the database doesn't already exists
    public void createDB() {

        try {
            // Get a connection
            connection = DriverManager.getConnection(URL, GAMEUSER, GAMEPASSWORD);
            System.out.println("Connected");

            // Create a statement
            Statement st = connection.createStatement();

            // Try to create a database called gamedata.
            st.execute(createDatabase);

            // Use the database gamedata
            st.execute("USE " + DBNAME);

            // Create a table (if the table does not already exist)
            st.execute(createTable);


        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    // This function updates the players into the MySQL database
        public void insertAndUpdatePlayers(List<Player> currentPlayers) {
        
        
        
        for(int i = 0; i < currentPlayers.size(); i++){
            try{
                Connection connection = DriverManager.getConnection(URL+DBNAME, GAMEUSER, GAMEPASSWORD);
                
                PreparedStatement ps = connection.prepareStatement(
                        "INSERT INTO playerinfo (name, r_win, r_lose, curr_points) " +
                        "VALUES (?, ?, ?, ?) " + 
                         "ON DUPLICATE KEY UPDATE " + 
                         "r_win = VALUES(r_win), r_lose = VALUES(r_lose), curr_points = VALUES(curr_points)");
                ps.setString(1, currentPlayers.get(i).getName());
                ps.setInt(2, currentPlayers.get(i).getWins());
                ps.setInt(3, currentPlayers.get(i).getLosses());
                ps.setString(4, Float.toString(currentPlayers.get(i).getFunds()));
                ps.executeUpdate();
                connection.commit();
                
            }catch(Exception e){
            }
                
        }
        
    }


    public List<Player> getHighScorePlayers(){
       
        List<Player> highScoreList = new ArrayList<>();
        try {
            connection = DriverManager.getConnection(URL+DBNAME, GAMEUSER, GAMEPASSWORD);
            
            Statement st = connection.createStatement();
            
            ResultSet rs = st.executeQuery("SELECT * from  " + TABLENAME );
            
            while (rs.next()) {
                
                Player player = new Player(rs.getString("name"),rs.getInt("r_win"),rs.getInt("r_lose"),rs.getFloat("curr_points"));
                
                highScoreList.add(player);
            }
            
            
        } catch (SQLException ex) {
            ex.printStackTrace();
        }finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        
         Collections.sort(highScoreList, new Comparator<Player>() {
            public int compare(Player a, Player b){
                return Float.valueOf(b.getFunds()).compareTo(Float.valueOf(a.getFunds()));
            }
         
        });
        
        return highScoreList;
        
    }
    
}

