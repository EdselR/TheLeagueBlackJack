package base;

/*
 Group: Edsel Rudy, Giancarlo Soriano, Jasmine Santos, Paprawin Boonyakida

 */
public enum PlayerType {
    HUMAN, COMPUTER;
}
