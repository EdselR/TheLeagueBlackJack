package base;

/*
 Group: Edsel Rudy, Giancarlo Soriano, Jasmine Santos, Paprawin Boonyakida

 */
// Enums used for the HandAction
public enum HandAction {
                   //  Numeric Value
    HIT,           //       0
    SPLIT,         //       1
    DOUBLE,        //       2
    STAND;         //       3
}
