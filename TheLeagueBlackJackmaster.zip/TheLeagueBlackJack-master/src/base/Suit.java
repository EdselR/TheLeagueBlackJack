/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package base;

/*
 Group: Edsel Rudy, Giancarlo Soriano, Jasmine Santos, Paprawin Boonyakida

 */

// Enums used for the suits of the card
  public enum Suit {
                    // Numeric Value
        DIAMONDS,   //    0
        SPADES,     //    1
        CLUBS,      //    2
        HEARTS      //    3
    }
